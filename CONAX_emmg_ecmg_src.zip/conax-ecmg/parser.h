#ifndef PARSER_H
#define PARSER_H
#include "conax_core.h"


extern void parse(char *daten,uint8_t menge,char *zurueck,int& senden);

#endif // PARSER_H



