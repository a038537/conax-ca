#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <cstring>
#include "conax_core.h"

union _key{
    uint8_t _bkey[16];
    uint32_t _ukey[4];
};

uint8_t emmbuffer[64] ={
0x12, 0x3E, 0x82, 0x70, 0x3B, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x32, 0x64, 0x10,
0x00, 0x00, 0x00, 0x00, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC,
0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC,
0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68
};

uint32_t key20[4];
uint32_t key21[4];
uint32_t ppuakey[4];
uint32_t systemkey[4];

uint8_t datum[2];


uint8_t dec2bcd_r(uint16_t dec)
{
    return (dec) ? ((dec2bcd_r( dec / 10 ) << 4) + (dec % 10)) : 0;
}

uint16_t _emmdate(int inday,int inmon, int inyear){


    union _CNX_DATE _conaxdate;

    _conaxdate._bit._tenyear = (inyear - 1990) / 10;
    _conaxdate._bit._years = (inyear - 1990) % 10;
    _conaxdate._bit._day = inday;
    _conaxdate._bit._month = inmon;

    return _conaxdate._outdate;
}


uint16_t _conax_datum(void){
    time_t rawtime; // = time(NULL);
    struct tm *ltm;// = localtime(&rawtime);

    rawtime = time(NULL);
    ltm = localtime(&rawtime);

    union _CNX_DATE _conaxdate;

    printf("Local-time: %02d.%02d.%04d %02d:%02d:%02d ", ltm->tm_mday, ltm->tm_mon +1 , ltm->tm_year + 1900, ltm->tm_hour, ltm->tm_min, ltm->tm_sec);
    ltm->tm_isdst ? printf("DST\n\n") : printf("\n\n");

    _conaxdate._bit._tenyear = ((ltm->tm_year + 1900) - 1990) / 10;
    _conaxdate._bit._years = ((ltm->tm_year + 1900) - 1990) % 10;
    _conaxdate._bit._day = ltm->tm_mday;
    _conaxdate._bit._month = ltm->tm_mon +1;

    return _conaxdate._outdate;
}

uint16_t _conax_time(void){
    time_t rawtime; // = time(NULL);
    struct tm *ltm;// = localtime(&rawtime);

    union _zeit{
        uint16_t _16;
        uint8_t _8[2];
    };

    union _zeit _xx;
    rawtime = time(NULL);
    ltm = localtime(&rawtime);
    _xx._8[1] = dec2bcd_r(ltm->tm_min);
    _xx._8[0] = dec2bcd_r(ltm->tm_sec);
    return _xx._16;
}


void _xtea_enc(uint32_t *target, uint32_t *key,uint8_t rounds){

  uint32_t delta = 0x9E3779B9,sum = 0;
  for (int i = 0; i < rounds;i++)
  {
    target[0] += (((target[1] << 4) ^ (target[1] >> 5)) + target[1]) ^ (sum + key[sum & 3]);
    sum += delta;
    target[1] += (((target[0] << 4) ^ (target[0] >> 5)) + target[0]) ^ (sum + key[(sum>>11) & 3]);
  }
}


void sign(uint32_t in[6][2],uint32_t *key){
    uint32_t cbc[2];
     for(int i = 0;i<5;i++){
        cbc[0] = in[i][0];
        cbc[1] = in[i][1];
        in[5][0] ^= cbc[0];
        in[5][1] ^= cbc[1];
        _xtea_enc(in[5],key,7);
    }
}

void encrypt(uint32_t in[6][2],uint32_t *key){

    uint32_t cbc[2];
    cbc[0] = cbc[1] = 0;
    for(int i = 0; i<5;i++){
        in[i][0] ^= cbc[0];
        in[i][1] ^= cbc[1];
        _xtea_enc(in[i],key,32);
        cbc[0] = in[i][0];
        cbc[1] = in[i][1];
    }

}


void readkeys(){

    union _key _k20;
    union _key _k21;

	FILE *fp = fopen("keys.txt","rt");
	bool fileopen = 0;
	char tkey[100] = {0};
	int idx = 0;

	if (fp == NULL) {
       	fprintf(stderr, "Can't read keys.txt.\n\n");
    } else {
		fprintf(stderr, "keys.txt opened\n\n");
		fileopen = 1;
	}

	if(fileopen){

			fgets(tkey,60,fp);
            printf("ECM-Key #20:\n");
			for(idx = 0;idx < 16;idx++){
				sscanf(&tkey[idx*3],"%hhx",&_k20._bkey[idx]);
				printf("%02X ",_k20._bkey[idx]);
			}
			if(feof(fp))fclose(fp);
            printf("\n\n");
            fgets(tkey,60,fp);
            printf("ECM-Key #21:\n");
			for(idx = 0;idx < 16;idx++){
				sscanf(&tkey[idx*3],"%hhx",&_k21._bkey[idx]);
				printf("%02X ",_k21._bkey[idx]);
			}
			if(feof(fp))fclose(fp);
			printf("\n\n");
		}

	fclose(fp);
    for(int i=0;i<4;i++){
        key20[i] = _k20._ukey[i];
        key21[i] = _k21._ukey[i];
    }

}


void readsyskey(){

    union _key _syskey;

	FILE *fp = fopen("syskey.txt","rt");
	bool fileopen = 0;
	char tkey[100] = {0};
	int idx = 0;

	if (fp == NULL) {
       	fprintf(stderr, "Can't read syskey.txt.\n\n");
    } else {
		fprintf(stderr, "syskey.txt opened\n\n");
		fileopen = 1;
	}

	if(fileopen){

			fgets(tkey,60,fp);
            printf("SYSTEM-Key: \n");
			for(idx = 0;idx < 16;idx++){
				sscanf(&tkey[idx*3],"%hhx",&_syskey._bkey[idx]);
				printf("%02X ",_syskey._bkey[idx]);
			}
			if(feof(fp))fclose(fp);
            printf("\n\n");
		}

	fclose(fp);
    for(int i=0;i<4;i++){
        systemkey[i] = _syskey._ukey[i];
    }

}




void generate_ecm(uint8_t *buffernew,uint8_t *access,uint8_t keynum,uint8_t *cw0 ,uint8_t *cw1){

    union _kkk{
        uint16_t _16date;
        uint8_t _8date[2];

    };
    union _kkk _xx;
    union _kkk _yy;

    _xx._16date = _conax_datum();
    _yy._16date = _conax_time();

    printf("CONAX-DATE: %04X\n\n",_xx._16date);

    buffernew[0x02] = 0x34;
    buffernew[0x03] = 0x70;
    buffernew[0x04] = 0x32;
    buffernew[0x05] = 0x64;
    buffernew[0x06] = keynum;

    union _ecm{
        uint8_t _in[0x30];
        uint32_t _xt[6][2];
    } ecm;

    memset(ecm._in,0,0x30);
    ecm._in[0] = _xx._8date[1];
    ecm._in[1] = _xx._8date[0];
    ecm._in[2] = _yy._8date[1];
    ecm._in[3] = _yy._8date[0];
    for(int i=0;i<8;i++){ecm._in[0x04+i] = cw1[i];}
    for(int i=0;i<8;i++){ecm._in[0x0c+i] = cw0[i];}
    for(int i=0;i<4;i++){ecm._in[0x14+i] = access[i+2];}
    for(int i=0;i<16;i++){ecm._in[0x18+i] = 0xcc;}
    for(int i=0;i<8;i++){ecm._in[0x28+i] = 0x61+i;}
    sign(ecm._xt,keynum == 0x20 ? key20: key21);
    encrypt(ecm._xt,keynum == 0x20 ? key20 : key21);
    for(int i =0;i<0x30;i++){buffernew[0x07+i] = ecm._in[i];}

}

uint8_t generate_emm(char *in,uint8_t *out){
    uint32_t ppua,ppsa,temp[2][2];
    int day,mon,year,day2,mon2,year2;
    uint32_t acc;
    char name[20] ={0};

    union _emm{
        uint8_t _in[0x30];
        uint32_t _xt[6][2];
    } emm;


    memcpy(&out[0],&emmbuffer[0],64);

        if(in[0] == 0x55){
            sscanf(in,"U:%d S:%d/%d/%d E:%d/%d/%d A:%08x N:%s SA:%d",&ppua,&day,&mon,&year,&day2,&mon2,&year2,&acc,&name[0],&ppsa);
            printf("Serial-No:   %d PPUA: %08X\n",ppua,ppua);
            printf("Start-date:  %02d.%02d.%d ",day,mon,year);
            printf("End-date: %02d.%d.%02d ",day2,mon2,year2);
            printf("Access Criteria: %08X\n",acc);
            printf("PPSA Update: %08X ",ppsa);
            if(strlen(name)>=1){
                    printf("Name: %s\n",name);
                    out[32] = 0xA0;
                    out[33] = 0x10;
                    memset(&out[34],0x20,0x0f);
                    memcpy(&out[34],&name[0],strlen(name));
            }
            out[8] = out[16] = ppua >> 24 & 0xff;
            out[9] = out[17] = ppua >> 16 & 0xff;
            out[10] = out[18] = ppua >> 8 & 0xff;
            out[11] = out[19] =  ppua & 0xff;
            out[20] = 0xA0;
            out[21] = 0x03;
            out[22] = _emmdate(day,mon,year) >> 8 & 0xff;
            out[23] = _emmdate(day,mon,year) & 0xff;
            out[24] = _emmdate(day2,mon2,year2) >> 8 & 0xff;
            out[25] = _emmdate(day2,mon2,year2) & 0xff;
            out[26] = 0xA0;
            out[27] = 0x04;
            out[28] = acc >> 24 & 0xff;
            out[29] = acc >> 16 & 0xff;
            out[30] = acc >> 8 & 0xff;
            out[31] = acc & 0xff;
            out[49] = 0xA0;
            out[50] = 0x02;
            out[51] = ppsa >> 24 & 0xff;
            out[52] = ppsa >> 16 & 0xff;
            out[53] = ppsa >> 8 & 0xff;
            out[54] = ppsa & 0xff;

            memset(&name,0,20);
            }

        if(in[0] == 0x47){
            printf("SHARED EMM\n");
            sscanf(in,"G:%d",&ppsa);
            printf("Shared Address: %d PPUA: %08X\n",ppsa,ppsa);

            out[8] = out[16] = ppsa >> 24 & 0xff;
            out[9] = out[17] = ppsa >> 16 & 0xff;
            out[10] = out[18] = ppsa >> 8 & 0xff;
            out[11] = out[19] =  ppsa & 0xff;
            out[20] = 0xA0;
            out[21] = 0x20;
            memcpy(&out[22],key20,16);
            out[38] = 0xA0;
            out[39] = 0x21;
            memcpy(&out[40],key21,16);
        }

            memcpy(&temp[0][0],&out[8],4);
            memcpy(&temp[1][0],&out[8],4);
            temp[0][1] = 0x66666666;
            temp[1][1] = 0x22222222;
            _xtea_enc(temp[0],systemkey,32);
            _xtea_enc(temp[1],systemkey,32);

            ppuakey[0] = temp[0][0];
            ppuakey[1] = temp[0][1];
            ppuakey[2] = temp[1][0];
            ppuakey[3] = temp[1][1];

            memcpy(&emm._in[0],&out[16],0x30);
            sign(emm._xt,ppuakey);
            encrypt(emm._xt,ppuakey);
            memcpy(&out[16],&emm._in[0],0x30);

            printf("USING KEY: %08X%08X%08X%08X\n",temp[0][0],temp[0][1],temp[1][0],temp[1][1]);

            for(int i = 0;i < 16;i++){printf("___");}
            printf("\n");

            for(int i = 0;i < 64;i++){printf("%02x ",out[i]); if((i%16)==15)printf("\n");}
            printf("\n");
            for(int i = 0;i < 16;i++){printf("___");}
            printf("\n\n");

    return 64;
}

