#ifndef CONAX_CORE
#define CONAX_CORE

#include <time.h>
#include <stdio.h>
#include <fstream>
#include <cstring>
#include <stdint.h>

union _CNX_DATE{
    uint16_t _outdate;
    struct{
        unsigned _month:4;
        unsigned _years:4;
        unsigned _day:5;
        unsigned _tenyear:3;
    }_bit;
};


using namespace std;
extern uint8_t generate_emm(char *in,uint8_t *out);
//extern void generate_ecm(uint8_t *buffernew,uint8_t *access,uint8_t keynum,uint8_t *cw0 ,uint8_t *cw1);
extern void readkeys(void);
extern void readsyskey(void);
#endif
